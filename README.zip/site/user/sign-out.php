<?php
session_destroy();
?>
<script>window.location.href="../../index.php"</script>