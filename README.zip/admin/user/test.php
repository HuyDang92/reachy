<!-- <div class="error__container">
    <h1>Chức năng này vẫn đang được phát triển :(</h1>
    <img src="/imgs/interface/404.webp" alt="">
</div>
 -->
<script>
    function test(){
        const huhu = document.querySelector('#hehe').nextElementSibling.nextElementSibling.value;
        console.log(huhu);
    }
</script>
<button id="hehe"onclick="test()">alo alo</button>
<input type="hidden" value="helo">
<input type="hidden" value="helo2">
<input type="hidden" value="helo3">