
<div class="admin__container">
    <h1>Chào mừng đến với trang quản trị</h1>
    <img src="<?=$CONTENT_URL?>/imgs/interface/admin-main.png" alt="">
</div>